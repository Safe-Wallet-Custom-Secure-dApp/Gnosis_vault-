# Safe Dashboard

This is the Safe{Wallet} Dashboard powered by GitHub Actions and Vercel.