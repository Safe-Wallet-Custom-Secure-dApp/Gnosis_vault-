# Project Application
_This is a guideline on how to apply for a project provided by Gnosis_

### Project
> For which of the projects are you applying

### Team members
> Name your team members 

### GitHub Repo
> Link to your GitHub Repo

### Project Portfolio
> Link to your projects you want to share with us

### Expertise
> Short summary of the expertise within your team?

### Why are you interested in working on the project?
> Short summary of your motivation

### How long will you need to build the project?
> Estimation of how long you will need to implement the project.

### Project implementation?
> Outline a detailed description of the project realization. How do you plan to implement this project, which tools and framework will you use? Please provide details on Architecture, Mockups, etc.

### How did you hear about the GECO?
> Website, Twitter, Conference and others

### Others
> Anything else you want to share with us
