import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';

const SAFE_ADDRESS = process.env.SAFE_ADDRESS!;
const SAFE_CHAIN = process.env.SAFE_CHAIN || 'arbitrum';
const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL;

const readmePath = path.resolve('README.md');

async function fetchSafeProposals(): Promise<string[]> {
  const url = `https://safe-transaction-${SAFE_CHAIN}.safe.global/api/v1/safes/${SAFE_ADDRESS}/multisig-transactions/?limit=5&executed=false`;

  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch Safe proposals: ${res.statusText}`);

  const data = await res.json();
  return data.results.map((tx: any) => {
    const shortHash = tx.safeTxHash.slice(0, 10) + '...';
    return `- 🧾 [Tx ${shortHash}](https://app.safe.global/transactions/tx?id=multisig_${SAFE_ADDRESS}_${tx.safeTxHash}) - nonce: ${tx.nonce}`;
  });
}

async function updateReadme() {
  const proposals = await fetchSafeProposals();
  const content = `## 🧠 Pending Safe Proposals (auto-updated)\n\n${proposals.join('\n') || '✅ No pending transactions.'}`;

  let readme = fs.readFileSync(readmePath, 'utf-8');
  const start = '<!-- SAFE_PROPOSALS_START -->';
  const end = '<!-- SAFE_PROPOSALS_END -->';

  if (!readme.includes(start)) {
    readme += `\n\n${start}\n${content}\n${end}\n`;
  } else {
    const pattern = new RegExp(`${start}[\\s\\S]*?${end}`, 'g');
    readme = readme.replace(pattern, `${start}\n${content}\n${end}`);
  }

  fs.writeFileSync(readmePath, readme);
  console.log('✅ README updated with Safe proposals.');

  if (DISCORD_WEBHOOK_URL) {
    await fetch(DISCORD_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: `📢 README updated with latest Safe proposals.\nChain: ${SAFE_CHAIN}\nAddress: ${SAFE_ADDRESS}` }),
    });
    console.log('✅ Discord notified.');
  }
}

updateReadme().catch(err => {
  console.error('❌ Error:', err.message);
  process.exit(1);
});
