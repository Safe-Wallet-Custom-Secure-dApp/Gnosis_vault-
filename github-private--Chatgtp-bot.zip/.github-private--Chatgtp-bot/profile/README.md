# 👋 Welcome to the ChatGTP SafeBot Org

This private space is for trusted builders, multisig signers, and Safe automation heroes.

> 🔐 All activity here is secured by Safe Wallets, Reown, and our GitHub App: [ChatGTP SafeBot](https://github.com/apps/chatgtp-safebot)

## 🧠 Quick Links
- Safe Dashboard: [https://chatgtp-bot-reown.xyz](https://chatgtp-bot-reown.xyz)
- Discord Webhook: Integrated ✅
- Signer Address: `0xAfD5...A0A0`
- Safe Address (Arbitrum): `0x821f...d675`

## 🛠 Org Bot Commands
- `/safe propose` — Propose a transaction
- `/safe sign` — Trigger signing from Discord/GitHub
- `/safe status` — Show latest Safe stats

## 🫂 Internal Only
This README is visible only to org members. Share secrets, coordinate signers, and build like a DAO.

> Made with 💙 by thegoodeth12
