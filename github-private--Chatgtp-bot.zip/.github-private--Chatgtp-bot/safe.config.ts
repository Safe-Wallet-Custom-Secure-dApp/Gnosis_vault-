// safe.config.ts

export const safeConfig = {
  projectName: "ChatGTP Safe Wallet",
  safeAddress: "0x821f2b40d965b81202b181Aba1c7a380C49Ed675", // Your Safe
  signerAddress: "0xAfD5f60aA8eb4F488eAA0eF98c1C5B0645D9A0A0", // Your signer
  network: "arbitrum", // or ethereum, base, etc.

  github: {
    org: "Chatgtp-bot",
    repo: ".github-private",
    defaultBranch: "reboot-setup",
  },

  discord: {
    webhook: "https://discord.com/api/webhooks/1390037095254327407/GvQDEEGEoiOPdKDkLqUaM__wVwIvx_qTE009RpLUMf-UZ6mWy5D4UmkWbf_Tn1OFTH8Y",
  },

  frontend: {
    appkitRepo: "https://github.com/thegoodeth12/automatisch-appkit.git",
    customDomain: "https://chatgtp-bot-reown.xyz",
    useExtension: true,
  },

  dashboard: {
    enableStats: true,
    showSigners: true,
    trackProposals: true,
  },

  secrets: {
    GITHUB_TOKEN: "${{ 

  }; 
  
   import { safeConfig } from "./safe.config";
  },
};
