This Action runs your script automatically to update the org README and notify Discord.
