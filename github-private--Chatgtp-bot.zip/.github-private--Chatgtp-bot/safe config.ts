export const safeConfig = {
  orgName: "Chatgtp-bot",
  description:
    "⚙️ Secure automation project powered by Safe Wallet, GitHub, Reown, and Discord. Built with ❤️ by thegoodeth.",
  safeAddress: "0x821f2b40d965b81202b181Aba1c7a380C49Ed675",
  network: "arbitrum",
  signerAddress: "0xAfD5f60aA8eb4F488eAA0eF98c1C5B0645D9A0A0",
  extensions: [
    "🔐 Safe AppKit UI (Reown)",
    "📡 Discord Webhook Notifications",
    "🤖 GitHub Actions Automation",
    "🧩 Safe Dashboard Extension",
    "🌐 Telegram Mini App (coming soon)",
  ],
};
