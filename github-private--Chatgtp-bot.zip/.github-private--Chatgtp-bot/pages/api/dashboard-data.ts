// pages/api/dashboard-data.ts
import type { NextApiRequest, NextApiResponse } from 'next'

type DashboardData = {
  safeWallets: string[]
  githubOrg: string
  proposals: string[]
  discordWebhook: string
}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<DashboardData>
) {
  const safeWallets = [
    '0x821f2b40d965b81202b181Aba1c7a380C49Ed675',
    '0xAfD5f60aA8eb4F488eAA0eF98c1C5B0645D9A0A0',
  ]

  const githubOrg = 'Chatgtp-bot'
  const proposals = [
    'Update README with Safe Proposals',
    'Enable Discord Signing Alerts',
    'Refactor GitHub Action for Safe Sync',
  ]

  const discordWebhook =
    'https://discord.com/api/webhooks/1390037095254327407/GvQDEEGEoiOPdKDkLqUaM__wVwIvx_qTE009RpLUMf-UZ6mWy5D4UmkWbf_Tn1OFTH8Y'

  res.status(200).json({
    safeWallets,
    githubOrg,
    proposals,
    discordWebhook,
  })
}
