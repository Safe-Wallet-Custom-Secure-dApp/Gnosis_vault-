// app/page.tsx

import SafeDashboard from '../components/SafeDashboard'

export default function HomePage() {
  return <SafeDashboard />
}
