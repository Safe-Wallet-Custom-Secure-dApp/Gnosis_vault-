// pages/api/dashboard-data.ts

import { getSafeDashboardData } from '@/scripts/extensions/safeDashboardExtension';

export default function handler(req, res) {
  const data = getSafeDashboardData();
  res.status(200).json(data);
}
