// scripts/extensions/safeDashboardExtension.ts

import fs from 'fs';
import path from 'path';

const safeConfigPath = path.resolve('safe.config.ts');
const readmePath = path.resolve('README.md');

export const getSafeDashboardData = () => {
  const safeConfig = fs.readFileSync(safeConfigPath, 'utf-8');
  const readme = fs.readFileSync(readmePath, 'utf-8');

  return {
    timestamp: new Date().toISOString(),
    configPreview: safeConfig.slice(0, 200) + '...',
    readmePreview: readme.slice(0, 200) + '...',
    discordWebhook: 'https://discord.com/api/webhooks/1390037095254327407/************',
    dashboardFeatures: ['Safe Balances', 'Owner Signers', 'Proposal Stats', 'GitHub Sync'],
  };
};

// For now, this just logs the preview
if (require.main === module) {
  console.log('🔍 Safe Dashboard Extension Preview:');
  console.log(getSafeDashboardData());
}
