import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';

const README_PATH = path.join(__dirname, '../../README.md');
const SAFE_ADDRESS = '0x821f2b40d965b81202b181Aba1c7a380C49Ed675';
const NETWORK = 'arbitrum';
const DISCORD_WEBHOOK = 'https://discord.com/api/webhooks/1390037095254327407/GvQDEEGEoiOPdKDkLqUaM__wVwIvx_qTE009RpLUMf-UZ6mWy5D4UmkWbf_Tn1OFTH8Y';

async function fetchSafeProposals() {
  const url = `https://safe-transaction-${NETWORK}.safe.global/api/v1/safes/${SAFE_ADDRESS}/multisig-transactions/?limit=3`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Error fetching proposals: ${res.statusText}`);
  const data = await res.json();
  return data.results;
}

async function updateReadme() {
  const proposals = await fetchSafeProposals();
  const lines = proposals.map((tx, idx) => {
    return `- Proposal #${tx.nonce}: [${tx.to}](${tx.dataDecoded?.method ?? 'Unknown method'})`;
  });

  const content = `# 🧠 Safe Proposals Dashboard\n\n## Latest Proposals\n\n${lines.join('\n')}\n\n_Last updated: ${new Date().toISOString()}_\n`;

  fs.writeFileSync(README_PATH, content);
  console.log('README.md updated successfully');

  // Notify Discord
  await fetch(DISCORD_WEBHOOK, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content: '✅ README updated with latest Safe proposals.' }),
  });
}

updateReadme().catch(console.error);
