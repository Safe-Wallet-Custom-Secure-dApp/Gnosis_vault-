// src/config/extension.ts

export const EXTENSION_CONFIG = {
  safeAddress: '0x821f2b40d965b81202b181Aba1c7a380C49Ed675',
  signer: '0xAfD5f60aA8eb4F488eAA0eF98c1C5B0645D9A0A0',
  env: 'production',
  dashboardURL: 'https://chatgtp-bot-reown.xyz',
  discordWebhook: 'https://discord.com/api/webhooks/1390037095254327407/GvQDEEGEoiOPdKDkLqUaM__wVwIvx_qTE009RpLUMf-UZ6mWy5D4UmkWbf_Tn1OFTH8Y',
  githubRepo: 'Chatgtp-bot/.github-private',
  reownEnabled: true,
  safeNetwork: 'arbitrum',
  appkitEnabled: true,
};
