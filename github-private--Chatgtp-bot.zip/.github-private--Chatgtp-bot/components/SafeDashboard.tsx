// components/SafeDashboard.tsx

'use client'

import React from 'react'
import { EXTNESION_CONFIG } from '../extension'

export default function SafeDashboard() {
  const {
    safeAddress,
    signer,
    githubRepo,
    discordWebhook,
    dashboardURL,
    appkitIntegration,
    reownEnabled,
    env,
  } = EXTNESION_CONFIG

  return (
    <div style={{ padding: 24 }}>
      <h1>🛡️ ChatGTP Safe Dashboard</h1>

      <ul>
        <li><strong>Signer:</strong> {signer}</li>
        <li><strong>Safe Address:</strong> {safeAddress}</li>
        <li><strong>GitHub:</strong> {githubRepo}</li>
        <li><strong>Discord Webhook:</strong> {discordWebhook ? '✅ Enabled' : '❌ Not Set'}</li>
        <li><strong>Dashboard URL:</strong> {dashboardURL}</li>
        <li><strong>AppKit Integration:</strong> {appkitIntegration ? '✅ Yes' : '❌ No'}</li>
        <li><strong>Reown Signing:</strong> {reownEnabled ? '✅ Enabled' : '❌ Disabled'}</li>
        <li><strong>Environment:</strong> {env}</li>
      </ul>

      <p style={{ marginTop: 20 }}>
        Built with ❤️ using Safe, Reown, GitHub Actions, and a little sprinkle of chaos magic 🔮
      </p>
    </div>
  )
}
